# -*- coding: utf-8 -*-
"""Domain layer - Pure business logic, hardware-independent"""
