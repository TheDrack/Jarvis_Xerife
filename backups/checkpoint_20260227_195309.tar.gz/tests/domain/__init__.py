# -*- coding: utf-8 -*-
"""Test configuration for domain tests"""
