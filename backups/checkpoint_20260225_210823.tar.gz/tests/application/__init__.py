# -*- coding: utf-8 -*-
"""Test configuration for application tests"""
