# -*- coding: utf-8 -*-
"""
Dynamic Plugin Directory

JARVIS can write new .py files here to auto-extend its capabilities.
All Python modules in this directory are automatically loaded on startup.
"""
