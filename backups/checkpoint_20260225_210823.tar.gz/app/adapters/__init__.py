# -*- coding: utf-8 -*-
"""Adapters - Concrete implementations of ports"""
