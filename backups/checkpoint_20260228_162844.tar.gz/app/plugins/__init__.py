# -*- coding: utf-8 -*-
"""
JARVIS Plugin System

This package provides infrastructure for JARVIS's auto-extensibility.
Plugins can be dynamically loaded and executed to extend JARVIS capabilities.
"""
