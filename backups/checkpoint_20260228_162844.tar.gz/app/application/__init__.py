# -*- coding: utf-8 -*-
"""Application layer - Use cases and ports (interfaces)"""
